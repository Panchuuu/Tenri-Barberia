import React, { useState, useEffect } from "react";
import toast from "react-hot-toast";
import apiFetch, { apiLogout } from "../utils/api";
import PerfilUsuario from "./PerfilUsuario";

export default function AdminDashboard({ usuario, setUsuario, onVolver }) {
  // Pestañas disponibles: 'agenda', 'historial', 'roles', 'servicios', 'configuracion'
  const [tabActiva, setTabActiva] = useState("agenda");

  // Estados para Usuarios/Barberos
  const [email, setEmail] = useState("");
  const [nombre, setNombre] = useState("");
  const [editandoId, setEditandoId] = useState(null);

  const [horaInicio, setHoraInicio] = useState("10:00");
  const [horaFin, setHoraFin] = useState("19:00");

  // Estados para Servicios
  const [servicios, setServicios] = useState([]);
  const [formServicio, setFormServicio] = useState({
    nombre: "",
    precio: "",
    duracion: "",
    descripcion: "",
  });

  const [editandoServicioId, setEditandoServicioId] = useState(null);

  // Estados generales
  const [barberos, setBarberos] = useState([]);
  const [citas, setCitas] = useState([]);
  const [finanzas, setFinanzas] = useState(null);

  const [paginacion, setPaginacion] = useState({ actual: 1, total: 1 });

  // Estado para la configuración de la barbería
  const [configBarberia, setConfigBarberia] = useState({
    tiempo_cancelacion: 60,
  });

  // Estado para el Modal de Confirmación personalizado
  const [modalConfirm, setModalConfirm] = useState({
    abierto: false,
    mensaje: "",
    onConfirm: null,
  });

  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async (pagina = 1) => {
    try {
      // 🔧 FIX FASE 1: endpoint multi-tenant safe (filtra por la barbería del admin)
      const resB = await apiFetch("/mi-equipo");
      if (resB.ok) setBarberos(await resB.json());

      const resC = await apiFetch(`/citas?page=${pagina}`);
      if (resC.ok) {
        const dataCitas = await resC.json();
        // Como usamos ->paginate() en Laravel, la lista de citas viene en .data
        setCitas(dataCitas.data);
        // Guardamos los metadatos de paginación
        setPaginacion({
          actual: dataCitas.current_page,
          total: dataCitas.last_page,
        });
      }

      const resF = await apiFetch("/finanzas/hoy");
      if (resF.ok) setFinanzas(await resF.json());

      // 🔧 FIX FASE 1: endpoint multi-tenant safe
      const resS = await apiFetch("/mis-servicios");
      if (resS.ok) setServicios(await resS.json());

      // Cargamos la configuración actual de la barbería
      const resConf = await apiFetch("/mi-barberia");
      if (resConf.ok) {
        const dataConf = await resConf.json();
        setConfigBarberia({ tiempo_cancelacion: dataConf.tiempo_cancelacion });
      }
    } catch (e) {
      console.error(e);
    }
  };

  // ==========================================
  // HELPERS MATEMÁTICOS PARA EL WIDGET DE TIEMPO
  // ==========================================
  const diasCancelacion = Math.floor(configBarberia.tiempo_cancelacion / 1440);
  const horasCancelacion = Math.floor(
    (configBarberia.tiempo_cancelacion % 1440) / 60,
  );
  const minutosCancelacion = configBarberia.tiempo_cancelacion % 60;

  const actualizarTiempoCancelacion = (d, h, m) => {
    // Calculamos el total de minutos. Si da negativo, lo dejamos en 0.
    let total = d * 1440 + h * 60 + m;
    if (total < 0) total = 0;
    setConfigBarberia({ ...configBarberia, tiempo_cancelacion: total });
  };

  // ==========================================
  // GESTIÓN DE CONFIGURACIÓN DE LA BARBERÍA
  // ==========================================
  const handleGuardarConfiguracion = async (e) => {
    e.preventDefault();

    try {
      const respuesta = await apiFetch("/mi-barberia", {
        method: "PUT",
        body: JSON.stringify({
          tiempo_cancelacion: configBarberia.tiempo_cancelacion,
        }),
      });

      if (respuesta.ok) {
        toast.success("Reglas de cancelación actualizadas");
        await cargarDatos();
      } else {
        toast.error("Error al actualizar configuración");
      }
    } catch (error) {
      console.error(error);
      toast.error("Error de conexión");
    }
  };

  // ==========================================
  // GESTIÓN DE SERVICIOS (CATÁLOGO)
  // ==========================================
  const handleGuardarServicio = async (e) => {
    e.preventDefault();

    const endpoint = editandoServicioId
      ? `/servicios/${editandoServicioId}`
      : "/servicios";

    const metodo = "POST";

    const formData = new FormData();
    formData.append("nombre", formServicio.nombre);
    formData.append("precio", formServicio.precio);
    formData.append("duracion", formServicio.duracion);
    formData.append("descripcion", formServicio.descripcion || "");

    if (formServicio.imagen_archivo) {
      formData.append("imagen", formServicio.imagen_archivo);
    }

    if (editandoServicioId) {
      formData.append("_method", "PUT");
    }

    try {
      const resp = await apiFetch(endpoint, {
        method: metodo,
        // apiFetch detecta automáticamente que es un FormData y no pisa el Content-Type
        body: formData,
      });

      if (resp.ok) {
        setFormServicio({
          nombre: "",
          precio: "",
          duracion: "",
          descripcion: "",
          imagen_archivo: null,
        });
        setEditandoServicioId(null);
        await cargarDatos();

        toast.success(
          editandoServicioId
            ? "Servicio actualizado correctamente"
            : "Servicio creado con éxito",
        );
      } else {
        const errorData = await resp.json();
        console.error("Detalles del rechazo:", errorData);

        let mensajeError = "Ocurrió un error al guardar";

        if (errorData.errors && errorData.errors.imagen) {
          mensajeError = "La imagen es demasiado pesada o inválida.";
        } else if (errorData.message) {
          mensajeError = "Revisa los datos ingresados.";
        }

        toast.error(mensajeError);
      }
    } catch (e) {
      console.error(e);
      toast.error("Error de conexión con el servidor");
    }
  };

  const confirmarEliminarServicio = (id) => {
    setModalConfirm({
      abierto: true,
      mensaje:
        "¿Seguro que deseas eliminar este servicio del catálogo? Esta acción no se puede deshacer.",
      onConfirm: async () => {
        setModalConfirm({ abierto: false, mensaje: "", onConfirm: null });
        try {
          const resp = await apiFetch(`/servicios/${id}`, {
            method: "DELETE",
          });
          if (resp.ok) {
            await cargarDatos();
            toast.success("Servicio eliminado del catálogo");
          } else {
            toast.error("No se pudo eliminar el servicio");
          }
        } catch (e) {
          console.error(e);
          toast.error("Error de conexión");
        }
      },
    });
  };

  // ==========================================
  // GESTIÓN DE BARBEROS Y ESTADOS
  // ==========================================
  const handleGuardarBarbero = async (e) => {
    e.preventDefault();

    const endpoint = editandoId
      ? `/barberos/${editandoId}`
      : "/barberos/asignar";
    const metodo = editandoId ? "PUT" : "POST";

    try {
      const respuesta = await apiFetch(endpoint, {
        method: metodo,
        body: JSON.stringify({
          email: email,
          name: nombre,
          hora_inicio: horaInicio,
          hora_fin: horaFin,
        }),
      });
      if (respuesta.ok) {
        setEditandoId(null);
        setNombre("");
        setEmail("");
        setHoraInicio("10:00");
        setHoraFin("19:00");
        await cargarDatos();
        toast.success(editandoId ? "Barbero actualizado" : "Barbero asignado");
      } else {
        toast.error("Ocurrió un error al guardar el Barbero");
      }
    } catch (e) {
      console.error(e);
      toast.error("Error de conexión con el servidor");
    }
  };

  const confirmarEliminarBarbero = (id) => {
    setModalConfirm({
      abierto: true,
      mensaje:
        "¿Seguro que deseas remover a este Barbero de tu barbería? Pasará a ser un usuario normal.",
      onConfirm: async () => {
        setModalConfirm({ abierto: false, mensaje: "", onConfirm: null });
        try {
          const resp = await apiFetch(`/barberos/${id}`, {
            method: "DELETE",
          });
          if (resp.ok) {
            await cargarDatos();
            toast.success("Barbero removido de la empresa");
          } else {
            toast.error("No se pudo remover al Barbero");
          }
        } catch (e) {
          console.error(e);
          toast.error("Error de conexión");
        }
      },
    });
  };

  const handleActualizarEstado = async (id, nuevoEstado) => {
    try {
      const respuesta = await apiFetch(`/citas/${id}/estado`, {
        method: "PATCH",
        body: JSON.stringify({ estado: nuevoEstado }),
      });
      if (respuesta.ok) {
        await cargarDatos();
        toast.success(`Cita marcada como ${nuevoEstado}`);
      } else {
        toast.error("No se pudo actualizar el estado de la cita");
      }
    } catch (e) {
      console.error(e);
      toast.error("Error de conexión con el servidor");
    }
  };

  const handleCerrarSesion = async () => {
    // 🔧 FIX FASE 1: revocamos el token en el servidor, no solo en localStorage
    await apiLogout();
    window.location.reload();
  };

  // Estilos visuales
  const getBadgeStyle = (estado) => {
    const estados = {
      pendiente: "text-amber-400 bg-amber-400/10",
      confirmada: "text-cyan-400 bg-cyan-400/10",
      finalizada: "text-emerald-400 bg-emerald-400/10",
      cancelada: "text-rose-400 bg-rose-400/10",
    };
    return estados[estado?.toLowerCase()] || "text-slate-400 bg-slate-800";
  };

  const isOperacionesActivo =
    tabActiva === "agenda" || tabActiva === "historial";
  const citasOperativas = citas.filter(
    (c) => c.estado === "pendiente" || c.estado === "confirmada",
  );
  const citasHistorial = citas.filter(
    (c) => c.estado === "finalizada" || c.estado === "cancelada",
  );

  return (
    <div className="fixed inset-0 z-[100] flex bg-[#060b14] text-slate-300 font-sans animate-fade-in">
      {/* SIDEBAR */}
      <aside className="w-[280px] bg-[#03070e] flex flex-col justify-between border-r border-slate-800/50">
        <div>
          <div className="h-24 flex items-center justify-center border-b border-slate-800/30 font-black text-xl text-white">
            TENRI <span className="text-emerald-400 ml-2">BARBER</span>
          </div>

          <nav className="p-4 space-y-2 mt-4 text-sm font-medium">
            <button
              onClick={() => setTabActiva("agenda")}
              className={`w-full text-left px-5 py-3 rounded-lg ${isOperacionesActivo ? "bg-[#0f1b29] text-emerald-400" : "text-slate-400 hover:bg-slate-800/30"}`}
            >
              Operaciones
            </button>

            {isOperacionesActivo && (
              <div className="ml-8 border-l border-slate-700/50 pl-4 py-2 space-y-3">
                <p
                  onClick={() => setTabActiva("agenda")}
                  className={`cursor-pointer ${tabActiva === "agenda" ? "text-emerald-400" : "text-slate-500 hover:text-slate-300"}`}
                >
                  Agenda General
                </p>
                <p
                  onClick={() => setTabActiva("historial")}
                  className={`cursor-pointer ${tabActiva === "historial" ? "text-emerald-400" : "text-slate-500 hover:text-slate-300"}`}
                >
                  Historial
                </p>
              </div>
            )}

            <button
              onClick={() => setTabActiva("servicios")}
              className={`w-full text-left px-5 py-3 rounded-lg ${tabActiva === "servicios" ? "bg-[#0f1b29] text-emerald-400" : "text-slate-400 hover:bg-slate-800/30"}`}
            >
              Catálogo de Servicios
            </button>

            <button
              onClick={() => setTabActiva("roles")}
              className={`w-full text-left px-5 py-3 rounded-lg ${tabActiva === "roles" ? "bg-[#0f1b29] text-emerald-400" : "text-slate-400 hover:bg-slate-800/30"}`}
            >
              Administración Equipo
            </button>

            {/* 👇 NUEVA PESTAÑA: AJUSTES DE NEGOCIO 👇 */}
            <button
              onClick={() => setTabActiva("configuracion")}
              className={`w-full text-left px-5 py-3 rounded-lg ${tabActiva === "configuracion" ? "bg-[#0f1b29] text-emerald-400" : "text-slate-400 hover:bg-slate-800/30"}`}
            >
              Ajustes de Negocio
            </button>
            <button
              onClick={() => setTabActiva("perfil")}
              className={`w-full text-left px-5 py-3 rounded-lg ${tabActiva === "perfil" ? "bg-[#0f1b29] text-emerald-400" : "text-slate-400 hover:bg-slate-800/30"}`}
            >
              👤 Mi Perfil
            </button>
          </nav>
        </div>

        <div className="p-5 border-t border-slate-800/50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-[#03070e] font-black text-xs">
              {usuario?.name?.substring(0, 2).toUpperCase()}
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-bold text-white leading-tight">
                {usuario?.name}
              </span>
              <span className="text-[10px] text-slate-500">Admin Tenri</span>
            </div>
          </div>
          <button
            onClick={handleCerrarSesion}
            className="text-slate-500 hover:text-rose-400 p-2"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="h-24 px-10 flex items-center justify-between shrink-0">
          <h2 className="text-3xl font-bold text-white tracking-tight">
            {tabActiva === "agenda" && "Panel Principal"}
            {tabActiva === "servicios" && "Gestión de Servicios"}
            {tabActiva === "roles" && "Gestión de Equipo"}
            {tabActiva === "configuracion" && "Ajustes de Negocio"}
          </h2>
          <button
            onClick={onVolver}
            className="px-5 py-2.5 bg-slate-800/50 hover:bg-slate-800 border border-slate-700 rounded-lg text-sm font-semibold transition-all"
          >
            Volver al Inicio
          </button>
        </header>

        <div className="flex-1 overflow-y-auto px-10 pb-10 custom-scrollbar">
          {tabActiva === "perfil" && (
            <PerfilUsuario usuario={usuario} setUsuario={setUsuario} />
          )}
          {/* ========================================== */}
          {/* VISTA: CONFIGURACIÓN (WIDGET INTERACTIVO) */}
          {/* ========================================== */}
          {tabActiva === "configuracion" && (
            <div className="bg-[#0B1221] border border-slate-800/60 rounded-2xl p-8 max-w-3xl shadow-xl animate-fade-in">
              <h3 className="text-xl font-bold text-white mb-2">
                Políticas y Reglas
              </h3>
              <p className="text-slate-500 text-sm mb-8">
                Define las reglas bajo las cuales los clientes interactúan con
                tu negocio.
              </p>

              <form onSubmit={handleGuardarConfiguracion} className="space-y-8">
                <div>
                  <label className="text-sm font-semibold text-slate-300 block mb-1">
                    Tiempo Límite de Cancelación
                  </label>
                  <p className="text-xs text-slate-500 mb-6">
                    Anticipación mínima requerida para que un cliente pueda
                    cancelar sin penalización.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Botón Días */}
                    <div className="bg-[#03070e] border border-slate-800/80 rounded-xl p-4 flex flex-col items-center shadow-inner">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">
                        Días
                      </span>
                      <div className="flex items-center gap-4">
                        <button
                          type="button"
                          onClick={() =>
                            actualizarTiempoCancelacion(
                              diasCancelacion - 1,
                              horasCancelacion,
                              minutosCancelacion,
                            )
                          }
                          className="w-8 h-8 rounded-full bg-slate-800 hover:bg-emerald-500 hover:text-[#03070e] text-white flex items-center justify-center font-bold transition-colors"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          value={diasCancelacion}
                          onChange={(e) =>
                            actualizarTiempoCancelacion(
                              parseInt(e.target.value) || 0,
                              horasCancelacion,
                              minutosCancelacion,
                            )
                          }
                          className="w-12 text-center bg-transparent text-2xl font-black text-white outline-none appearance-none"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            actualizarTiempoCancelacion(
                              diasCancelacion + 1,
                              horasCancelacion,
                              minutosCancelacion,
                            )
                          }
                          className="w-8 h-8 rounded-full bg-slate-800 hover:bg-emerald-500 hover:text-[#03070e] text-white flex items-center justify-center font-bold transition-colors"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Botón Horas */}
                    <div className="bg-[#03070e] border border-slate-800/80 rounded-xl p-4 flex flex-col items-center shadow-inner">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">
                        Horas
                      </span>
                      <div className="flex items-center gap-4">
                        <button
                          type="button"
                          onClick={() =>
                            actualizarTiempoCancelacion(
                              diasCancelacion,
                              horasCancelacion - 1,
                              minutosCancelacion,
                            )
                          }
                          className="w-8 h-8 rounded-full bg-slate-800 hover:bg-emerald-500 hover:text-[#03070e] text-white flex items-center justify-center font-bold transition-colors"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          value={horasCancelacion}
                          onChange={(e) =>
                            actualizarTiempoCancelacion(
                              diasCancelacion,
                              parseInt(e.target.value) || 0,
                              minutosCancelacion,
                            )
                          }
                          className="w-12 text-center bg-transparent text-2xl font-black text-white outline-none appearance-none"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            actualizarTiempoCancelacion(
                              diasCancelacion,
                              horasCancelacion + 1,
                              minutosCancelacion,
                            )
                          }
                          className="w-8 h-8 rounded-full bg-slate-800 hover:bg-emerald-500 hover:text-[#03070e] text-white flex items-center justify-center font-bold transition-colors"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Botón Minutos (Saltos de 15) */}
                    <div className="bg-[#03070e] border border-slate-800/80 rounded-xl p-4 flex flex-col items-center shadow-inner">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">
                        Minutos
                      </span>
                      <div className="flex items-center gap-4">
                        <button
                          type="button"
                          onClick={() =>
                            actualizarTiempoCancelacion(
                              diasCancelacion,
                              horasCancelacion,
                              minutosCancelacion - 15,
                            )
                          }
                          className="w-8 h-8 rounded-full bg-slate-800 hover:bg-emerald-500 hover:text-[#03070e] text-white flex items-center justify-center font-bold transition-colors"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          value={minutosCancelacion}
                          onChange={(e) =>
                            actualizarTiempoCancelacion(
                              diasCancelacion,
                              horasCancelacion,
                              parseInt(e.target.value) || 0,
                            )
                          }
                          className="w-12 text-center bg-transparent text-2xl font-black text-white outline-none appearance-none"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            actualizarTiempoCancelacion(
                              diasCancelacion,
                              horasCancelacion,
                              minutosCancelacion + 15,
                            )
                          }
                          className="w-8 h-8 rounded-full bg-slate-800 hover:bg-emerald-500 hover:text-[#03070e] text-white flex items-center justify-center font-bold transition-colors"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Resumen Visual */}
                  <div className="mt-6 text-center bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-4 rounded-xl text-sm font-medium">
                    Total configurado en la base de datos:{" "}
                    <span className="font-black text-lg ml-1">
                      {configBarberia.tiempo_cancelacion}
                    </span>{" "}
                    minutos.
                    {configBarberia.tiempo_cancelacion === 0 && (
                      <p className="text-rose-400 mt-1 text-xs">
                        ⚠️ Tus clientes podrán cancelar hasta el último minuto.
                      </p>
                    )}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-800/60">
                  <button
                    type="submit"
                    className="w-full md:w-auto px-8 py-3 bg-emerald-500 hover:bg-emerald-400 text-[#03070e] font-bold rounded-lg transition-colors shadow-lg shadow-emerald-500/20"
                  >
                    Guardar Configuración
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* VISTA: SERVICIOS */}
          {tabActiva === "servicios" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fade-in">
              <div className="lg:col-span-4 bg-[#0B1221] border border-slate-800/60 rounded-2xl p-8 h-fit shadow-xl">
                <h3 className="text-lg font-bold text-white mb-6">
                  {editandoServicioId ? "Editar Servicio" : "Nuevo Servicio"}
                </h3>
                <form onSubmit={handleGuardarServicio} className="space-y-5">
                  <div>
                    <label className="text-xs font-semibold text-slate-500 uppercase mb-2 block">
                      Nombre del Servicio
                    </label>
                    <input
                      type="text"
                      value={formServicio.nombre}
                      onChange={(e) =>
                        setFormServicio({
                          ...formServicio,
                          nombre: e.target.value,
                        })
                      }
                      className="w-full bg-[#03070e] border border-slate-800 rounded-lg p-3 text-sm text-slate-200 outline-none focus:border-emerald-500/50"
                      required
                      placeholder="Ej: Corte Degradado"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-semibold text-slate-500 uppercase mb-2 block">
                        Precio (CLP)
                      </label>
                      <input
                        type="number"
                        value={formServicio.precio}
                        onChange={(e) =>
                          setFormServicio({
                            ...formServicio,
                            precio: e.target.value,
                          })
                        }
                        className="w-full bg-[#03070e] border border-slate-800 rounded-lg p-3 text-sm text-slate-200 outline-none focus:border-emerald-500/50"
                        required
                        placeholder="15000"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-500 uppercase mb-2 block">
                        Duración (Min)
                      </label>
                      <input
                        type="number"
                        value={formServicio.duracion}
                        onChange={(e) =>
                          setFormServicio({
                            ...formServicio,
                            duracion: e.target.value,
                          })
                        }
                        className="w-full bg-[#03070e] border border-slate-800 rounded-lg p-3 text-sm text-slate-200 outline-none focus:border-emerald-500/50"
                        required
                        placeholder="30"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-500 uppercase mb-2 block">
                      Descripción (Breve)
                    </label>
                    <textarea
                      value={formServicio.descripcion}
                      onChange={(e) =>
                        setFormServicio({
                          ...formServicio,
                          descripcion: e.target.value,
                        })
                      }
                      className="w-full bg-[#03070e] border border-slate-800 rounded-lg p-3 text-sm text-slate-200 outline-none focus:border-emerald-500/50 h-24 resize-none"
                      placeholder="Corte de cabello a tijera o máquina..."
                    ></textarea>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-500 uppercase mb-2 block">
                      Foto del Servicio (Opcional)
                    </label>
                    <input
                      type="file"
                      accept="image/*"
                      // Cuando el usuario elige un archivo, lo guardamos en el estado 'imagen_archivo'
                      onChange={(e) =>
                        setFormServicio({
                          ...formServicio,
                          imagen_archivo: e.target.files[0],
                        })
                      }
                      className="w-full bg-[#03070e] border border-slate-800 rounded-lg p-2 text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-emerald-500/10 file:text-emerald-500 hover:file:bg-emerald-500/20 cursor-pointer"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-emerald-500 hover:bg-emerald-400 text-[#03070e] font-bold py-3 rounded-lg transition-colors"
                  >
                    {editandoServicioId
                      ? "Actualizar Servicio"
                      : "Crear Servicio"}
                  </button>
                  {editandoServicioId && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditandoServicioId(null);
                        setFormServicio({
                          nombre: "",
                          precio: "",
                          duracion: "",
                          descripcion: "",
                          imagen_archivo: null,
                        });
                      }}
                      className="w-full text-slate-500 text-xs mt-2"
                    >
                      Cancelar Edición
                    </button>
                  )}
                </form>
              </div>

              <div className="lg:col-span-8 bg-[#0B1221] border border-slate-800/60 rounded-2xl shadow-xl overflow-hidden">
                <table className="w-full text-left text-sm">
                  <thead className="bg-[#080d18] border-b border-slate-800/60 text-slate-400 font-semibold uppercase text-[10px] tracking-widest">
                    <tr>
                      <th className="px-8 py-5">Servicio</th>
                      <th className="px-8 py-5">Duración</th>
                      <th className="px-8 py-5">Precio</th>
                      <th className="px-8 py-5 text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40">
                    {servicios.map((s) => (
                      <tr
                        key={s.id}
                        className="hover:bg-slate-800/20 transition-colors"
                      >
                        <td className="px-8 py-5 flex items-center gap-4">
                          {s.imagen_url ? (
                            <img
                              src={s.imagen_url}
                              alt={s.nombre}
                              className="w-10 h-10 rounded-lg object-cover border border-slate-700/50 shadow-md"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-lg bg-slate-800/50 flex items-center justify-center border border-slate-700/50 text-slate-500">
                              <svg
                                className="w-5 h-5"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth="1.5"
                                  d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 5.758a3 3 0 10-4.243 4.243 3 3 0 004.243-4.243zm0-5.758a3 3 0 10-4.243-4.243 3 3 0 004.243 4.243z"
                                ></path>
                              </svg>
                            </div>
                          )}
                          <span className="text-slate-200 font-bold">
                            {s.nombre}
                          </span>
                        </td>
                        <td className="px-8 py-5 text-slate-400">
                          {s.duracion} min
                        </td>
                        <td className="px-8 py-5 text-emerald-400 font-mono">
                          ${s.precio?.toLocaleString("es-CL")}
                        </td>
                        <td className="px-8 py-5 text-right space-x-4">
                          <button
                            onClick={() => {
                              setEditandoServicioId(s.id);
                              // 🔧 FIX FASE 1: solo cargamos los campos del form, no imagen_url ni objetos extra
                              setFormServicio({
                                nombre: s.nombre || "",
                                precio: s.precio || "",
                                duracion: s.duracion || s.duracion_minutos || "",
                                descripcion: s.descripcion || "",
                                imagen_archivo: null,
                              });
                            }}
                            className="text-cyan-500 text-xs font-bold uppercase"
                          >
                            Editar
                          </button>
                          <button
                            onClick={() => confirmarEliminarServicio(s.id)}
                            className="text-rose-500 text-xs font-bold uppercase"
                          >
                            Borrar
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* VISTA: AGENDA */}
          {tabActiva === "agenda" && (
            <div className="space-y-8">
              {finanzas && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fade-in">
                  <div className="bg-[#0B1221] border border-slate-800/60 rounded-2xl p-6 shadow-xl">
                    <p className="text-slate-500 text-[10px] font-bold uppercase mb-1">
                      Ingresos de Hoy
                    </p>
                    <h3 className="text-3xl font-black text-white">
                      ${finanzas.total_ingresos?.toLocaleString("es-CL")}
                    </h3>
                  </div>
                  <div className="bg-[#0B1221] border border-slate-800/60 rounded-2xl p-6 shadow-xl">
                    <p className="text-slate-500 text-[10px] font-bold uppercase mb-1">
                      Cortes Finalizados
                    </p>
                    <h3 className="text-3xl font-black text-white">
                      {finanzas.cantidad_cortes}
                    </h3>
                  </div>
                  <div className="bg-[#0B1221] border border-slate-800/60 rounded-2xl p-6 shadow-xl overflow-y-auto max-h-24">
                    <p className="text-slate-500 text-[10px] font-bold uppercase mb-2">
                      Por Barbero
                    </p>
                    {Object.entries(finanzas.desglose_barberos || {}).map(
                      ([n, t]) => (
                        <div
                          key={n}
                          className="flex justify-between text-xs mb-1"
                        >
                          <span>{n}</span>
                          <span className="text-emerald-400 font-bold">
                            ${t.toLocaleString("es-CL")}
                          </span>
                        </div>
                      ),
                    )}
                  </div>
                </div>
              )}

              <div className="bg-[#0B1221] border border-slate-800/60 rounded-2xl overflow-hidden shadow-xl animate-fade-in">
                <table className="w-full text-left text-sm">
                  <thead className="bg-[#080d18] border-b border-slate-800/60 text-slate-400 font-semibold uppercase text-[10px] tracking-widest">
                    <tr>
                      <th className="px-8 py-4">Fecha / Hora</th>
                      <th className="px-8 py-4">Cliente</th>
                      <th className="px-8 py-4">Barbero</th>
                      <th className="px-8 py-4 text-center">Estado</th>
                      <th className="px-8 py-4 text-right">Acción</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40">
                    {citasOperativas.map((c) => (
                      <tr key={c.id} className="hover:bg-slate-800/20">
                        <td className="px-8 py-5">
                          <span className="font-bold text-slate-200">
                            {c.fecha}
                          </span>{" "}
                          <span className="text-slate-500 ml-4 font-mono text-xs">
                            {c.hora}
                          </span>
                        </td>
                        <td className="px-8 py-5 text-slate-300">
                          {c.cliente?.name}
                        </td>
                        <td className="px-8 py-5 text-slate-400">
                          {c.barbero?.name}
                        </td>
                        <td className="px-8 py-5 text-center">
                          <span
                            className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${getBadgeStyle(c.estado)}`}
                          >
                            {c.estado}
                          </span>
                        </td>
                        <td className="px-8 py-5 text-right">
                          {c.estado === "pendiente" && (
                            <div className="flex gap-3 justify-end">
                              <button
                                onClick={() =>
                                  handleActualizarEstado(c.id, "confirmada")
                                }
                                className="text-emerald-500 font-bold text-xs uppercase"
                              >
                                Confirmar
                              </button>
                              <button
                                onClick={() =>
                                  handleActualizarEstado(c.id, "cancelada")
                                }
                                className="text-rose-500 font-bold text-xs uppercase"
                              >
                                Cancelar
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {/* ========================================== */}
                {/* 👇 PEGA ESTE BLOQUE AQUÍ (PAGINACIÓN) 👇 */}
                {/* ========================================== */}
                <div className="flex items-center justify-between bg-[#080d18] px-8 py-4 border-t border-slate-800/60">
                  <p className="text-xs text-slate-500 font-medium">
                    Página{" "}
                    <span className="text-white">{paginacion.actual}</span> de{" "}
                    {paginacion.total}
                  </p>
                  <div className="flex gap-2">
                    <button
                      disabled={paginacion.actual === 1}
                      onClick={() => cargarDatos(paginacion.actual - 1)}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed rounded-lg text-xs font-bold transition-colors"
                    >
                      Anterior
                    </button>
                    <button
                      disabled={paginacion.actual === paginacion.total}
                      onClick={() => cargarDatos(paginacion.actual + 1)}
                      className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-[#03070e] disabled:opacity-30 disabled:cursor-not-allowed rounded-lg text-xs font-bold transition-colors"
                    >
                      Siguiente
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* VISTA: HISTORIAL */}
          {tabActiva === "historial" && (
            <div className="bg-[#0B1221] border border-slate-800/60 rounded-2xl overflow-hidden shadow-xl opacity-90">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#080d18] border-b border-slate-800/60 text-slate-500 font-semibold uppercase text-[10px] tracking-widest">
                  <tr>
                    <th className="px-8 py-4">ID</th>
                    <th className="px-8 py-4">Fecha / Hora</th>
                    <th className="px-8 py-4">Cliente</th>
                    <th className="px-8 py-4 text-right">Estado Final</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40">
                  {citasHistorial.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-800/20">
                      <td className="px-8 py-4 text-slate-600 font-mono text-xs">
                        #{c.id}
                      </td>
                      <td className="px-8 py-4 text-slate-400">
                        {c.fecha} {c.hora}
                      </td>
                      <td className="px-8 py-4 text-slate-400">
                        {c.cliente?.name}
                      </td>
                      <td className="px-8 py-4 text-right">
                        <span
                          className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${getBadgeStyle(c.estado)}`}
                        >
                          {c.estado}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* VISTA: EQUIPO */}
          {tabActiva === "roles" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fade-in">
              {/* Formulario Barberos */}
              <div className="lg:col-span-4 bg-[#0B1221] border border-slate-800/60 rounded-2xl p-8 h-fit shadow-xl">
                <h3 className="text-lg font-bold text-white mb-6">
                  {editandoId ? "Editar Barbero" : "Nuevo Barbero"}
                </h3>
                <form onSubmit={handleGuardarBarbero} className="space-y-6">
                  {editandoId && (
                    <div>
                      <label className="text-xs font-semibold text-slate-500 uppercase mb-2 block">
                        Nombre
                      </label>
                      <input
                        type="text"
                        value={nombre}
                        onChange={(e) => setNombre(e.target.value)}
                        className="w-full bg-[#03070e] border border-slate-800 rounded-lg p-3 text-sm text-slate-200 outline-none focus:border-emerald-500/50"
                        required
                      />
                    </div>
                  )}
                  <div>
                    <label className="text-xs font-semibold text-slate-500 uppercase mb-2 block">
                      Correo
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={editandoId !== null}
                      className={`w-full bg-[#03070e] border border-slate-800 rounded-lg p-3 text-sm text-slate-200 outline-none focus:border-emerald-500/50 ${editandoId ? "opacity-50 cursor-not-allowed" : ""}`}
                      required
                    />
                  </div>

                  {/* Inputs de Horario */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-semibold text-slate-500 uppercase mb-2 block">
                        Hora Entrada
                      </label>
                      <input
                        type="time"
                        value={horaInicio}
                        onChange={(e) => setHoraInicio(e.target.value)}
                        className="w-full bg-[#03070e] border border-slate-800 rounded-lg p-3 text-sm text-slate-200 outline-none focus:border-emerald-500/50"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-500 uppercase mb-2 block">
                        Hora Salida
                      </label>
                      <input
                        type="time"
                        value={horaFin}
                        onChange={(e) => setHoraFin(e.target.value)}
                        className="w-full bg-[#03070e] border border-slate-800 rounded-lg p-3 text-sm text-slate-200 outline-none focus:border-emerald-500/50"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-emerald-500 hover:bg-emerald-400 text-[#03070e] font-bold py-3 rounded-lg transition-colors"
                  >
                    {editandoId ? "Guardar Cambios" : "Asignar Rol"}
                  </button>

                  {editandoId && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditandoId(null);
                        setNombre("");
                        setEmail("");
                        setHoraInicio("10:00");
                        setHoraFin("19:00");
                      }}
                      className="w-full text-slate-500 text-xs mt-2"
                    >
                      Cancelar Edición
                    </button>
                  )}
                </form>
              </div>

              {/* Lista de Barberos */}
              <div className="lg:col-span-8 bg-[#0B1221] border border-slate-800/60 rounded-2xl shadow-xl overflow-hidden">
                <div className="divide-y divide-slate-800/40">
                  {barberos.map((b) => (
                    <div
                      key={b.id}
                      className="flex items-center justify-between px-8 py-5 hover:bg-slate-800/20 group"
                    >
                      <div className="flex items-center gap-5">
                        <div className="w-10 h-10 rounded-full bg-[#03070e] border border-slate-700/50 flex items-center justify-center font-bold text-slate-300 text-xs">
                          {b.name.substring(0, 1).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-slate-200 font-semibold">
                            {b.name}
                          </p>
                          <p className="text-xs text-slate-500">{b.email}</p>
                        </div>
                        {/* Muestra visual del turno */}
                        <div className="hidden md:flex ml-6 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 text-xs font-mono font-bold">
                          Turno:{" "}
                          {b.hora_inicio
                            ? b.hora_inicio.substring(0, 5)
                            : "10:00"}{" "}
                          - {b.hora_fin ? b.hora_fin.substring(0, 5) : "19:00"}
                        </div>
                      </div>
                      <div className="flex gap-4 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => {
                            setEditandoId(b.id);
                            setNombre(b.name);
                            setEmail(b.email);
                            setHoraInicio(
                              b.hora_inicio
                                ? b.hora_inicio.substring(0, 5)
                                : "10:00",
                            );
                            setHoraFin(
                              b.hora_fin ? b.hora_fin.substring(0, 5) : "19:00",
                            );
                          }}
                          className="text-emerald-500 text-[10px] font-bold uppercase"
                        >
                          Editar
                        </button>
                        <button
                          onClick={() => confirmarEliminarBarbero(b.id)}
                          className="text-rose-500 text-[10px] font-bold uppercase"
                        >
                          Remover
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* ========================================== */}
      {/* MODAL DE CONFIRMACIÓN CUSTOM (DISEÑO PREMIUM) */}
      {/* ========================================== */}
      {modalConfirm.abierto && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-[#03070e]/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0B1221] border border-slate-800 rounded-2xl p-6 w-[400px] shadow-2xl transform transition-all scale-100">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-10 h-10 rounded-full bg-rose-500/10 flex items-center justify-center shrink-0">
                <svg
                  className="w-5 h-5 text-rose-500"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                  ></path>
                </svg>
              </div>
              <h3 className="text-lg font-bold text-white">Confirmar Acción</h3>
            </div>

            <p className="text-sm text-slate-400 mb-8 pl-14">
              {modalConfirm.mensaje}
            </p>

            <div className="flex gap-3 justify-end">
              <button
                onClick={() =>
                  setModalConfirm({
                    abierto: false,
                    mensaje: "",
                    onConfirm: null,
                  })
                }
                className="px-5 py-2.5 text-sm font-semibold text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={modalConfirm.onConfirm}
                className="px-5 py-2.5 bg-rose-500 hover:bg-rose-400 text-[#03070e] font-bold rounded-lg transition-colors"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
